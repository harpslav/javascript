//deklaracja funkcji

//function showConsole() {
//    console.log("Jestem funkcją!");
//}
//
////wywyołanie funkcji
//
//showConsole();
//



var imie = "Adam";
var nazwisko = "Nowak";

//function wyswietl() {
//    console.log(imie + " " + nazwisko)
//}
//
//wyswietl();


function wyswietl( _imie_, nazwisko ) {
    
    console.log(_imie_ + " " + _nazwisko_)
}


wyswietl( imie, nazwisko );