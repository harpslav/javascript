// komentarz liniowy
// skrót kawiatury Ctrl + /

//tekst
//tekst2

/*

wszytsko co się znajdzie między znakami

zostanie pominięte przy komplikacji

TO JEST KOMENTARZ BLOKOWY


*/