//zmienna zadeklarowana bez przypisania wartości indefined

var imie;

/*


dalsza cześć programu


*/

//przypisanie wartości do wcześniejszej zdeklarowanej zminnej bez var
imie = "Adam";



// deklaracja zmiennej wraz z przypisanymi wartościami
var nazwisko = "Nowak";

console.log( imie + " " + nazwisko );


//notacja camelCase

var oprocentowanieBankowe = 5;

// obliczenie / działanie

var wynik = 1520;

/*

tutaj dlasza część programu

*/

//część kodu wykorzystująca wynik obliczenia z początku programu
console.log(wynik);
























